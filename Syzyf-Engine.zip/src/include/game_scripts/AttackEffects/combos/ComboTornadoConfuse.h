#pragma once
#include "ComboEffectBase.h"

class ComboTornadoConfuse : public ComboEffectBase {
public:
    float maxTornadoRadius = 5.0f;
    float rotationSpeed    = 90.0f;  // degrees/s
    int   ingredientCount  = 1;

    /// Wywo�aj po Init() � ustawia skal� w�z�a na podstawie effect2Strength.
    void InitTornado();

    void Update();

private:
    float m_TornadoRadius = 0.0f;

    void ApplyConfuseTo(EnemyBase* enemy);
    void ScanAndHandleBullets();
};