#pragma once

#include <GameObjectSystem.h>
#include "animation/SkeletonComponent.h"

#include <glad/glad.h>

class SkeletonSystem : public GameObjectSystem<SkeletonComponent> {
private:
  GLuint skinningBuffer;
  std::size_t currentBufferSize = 0;
public:
  SkeletonSystem(Scene* scene);

  // preupdate or postupdate?
  void OnPreUpdate();

  GLuint GetSkinningBufferHandle();
};
