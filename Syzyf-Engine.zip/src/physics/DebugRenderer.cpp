#include "physics/DebugRenderer.h"
#include "Camera.h"
#include "Frustum.h"
#include "Resources.h"
#include "Shader.h"
#include "Scene.h"
#include <glm/gtc/type_ptr.hpp>

namespace Physics {
void DebugRenderer::Init(ShaderProgram* debugShader) {
    shader = debugShader;

    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);

    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(6, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(6);

    glBindVertexArray(0);
}

void DebugRenderer::DrawLine(JPH::RVec3Arg inFrom, JPH::RVec3Arg inTo, JPH::ColorArg inColor)
{
    JPH::Vec4 color = inColor.ToVec4();

    lines.push_back({
        (float)inFrom.GetX(), (float)inFrom.GetY(), (float)inFrom.GetZ(),
        color.GetX(), color.GetY(), color.GetZ()
    });

    lines.push_back({
        (float)inTo.GetX(), (float)inTo.GetY(), (float)inTo.GetZ(),
        color.GetX(), color.GetY(), color.GetZ()
    });
}

void DebugRenderer::DrawTriangle(JPH::RVec3Arg inV1, JPH::RVec3Arg inV2, JPH::RVec3Arg inV3, JPH::ColorArg inColor, ECastShadow inCastShadow) {}

void DebugRenderer::DrawText3D(JPH::RVec3Arg inPosition, const std::string_view &inString, JPH::ColorArg inColor, float inHeight) {}

void DebugRenderer::DrawBoundingBox(const BoundingBox& box, JPH::ColorArg color, glm::mat4 transform) {
  JPH::Vec3 halfExtents(box.axisU.w, box.axisV.w, box.axisW.w);
  JPH::AABox boxLocal(-halfExtents, halfExtents);

  glm::vec3 u = glm::vec3(box.axisU);
  glm::vec3 v = glm::vec3(box.axisV);
  glm::vec3 w = glm::vec3(box.axisW);
  glm::vec3 p = box.center;

  JPH::Mat44 finalTransform(
    JPH::Vec4(u.x, u.y, u.z, 0),
    JPH::Vec4(v.x, v.y, v.z, 0),
    JPH::Vec4(w.x, w.y, w.z, 0),
    JPH::Vec4(p.x, p.y, p.z, 1)
  );

    JPH::Mat44 outMat;
    for (int row = 0; row < 4; ++row) {
        for (int col = 0; col < 4; ++col) {
            outMat(col, row) = transform[row][col];
        }
    }

  DrawWireBox(finalTransform * outMat, boxLocal, color);
}

void DebugRenderer::DrawFrustum(glm::mat4 viewProjection, JPH::ColorArg color) {
  glm::mat4 inverseViewProjection = glm::inverse(viewProjection);

  glm::vec4 ndcCube[8] = {
    {-1.0f, -1.0f, -1.0f, 1.0f},
    {1.0f, -1.0f, -1.0f, 1.0f},
    {1.0f, 1.0f, -1.0f, 1.0f},
    {-1.0f, 1.0f, -1.0f, 1.0f},
    {-1.0f, -1.0f, 1.0f, 1.0f},
    {1.0f, -1.0f, 1.0f, 1.0f},
    {1.0f, 1.0f, 1.0f, 1.0f},
    {-1.0f, 1.0f, 1.0f, 1.0f},
  };

  glm::vec3 frustumCorners[8];
  for (int i = 0; i < 8; ++i) {
    glm::vec4 corner = inverseViewProjection * ndcCube[i];
    frustumCorners[i] = glm::vec3(corner) / corner.w;
  }

  DrawLine(
    JPH::RVec3(frustumCorners[0].x, frustumCorners[0].y, frustumCorners[0].z),
    JPH::RVec3(frustumCorners[1].x, frustumCorners[1].y, frustumCorners[1].z),
    color
  );
  DrawLine(
    JPH::RVec3(frustumCorners[1].x, frustumCorners[1].y, frustumCorners[1].z),
    JPH::RVec3(frustumCorners[2].x, frustumCorners[2].y, frustumCorners[2].z),
    color
  );
  DrawLine(
    JPH::RVec3(frustumCorners[2].x, frustumCorners[2].y, frustumCorners[2].z),
    JPH::RVec3(frustumCorners[3].x, frustumCorners[3].y, frustumCorners[3].z),
    color
  );
  DrawLine(
    JPH::RVec3(frustumCorners[3].x, frustumCorners[3].y, frustumCorners[3].z),
    JPH::RVec3(frustumCorners[0].x, frustumCorners[0].y, frustumCorners[0].z),
    color
  );

  DrawLine(
    JPH::RVec3(frustumCorners[4].x, frustumCorners[4].y, frustumCorners[4].z),
    JPH::RVec3(frustumCorners[5].x, frustumCorners[5].y, frustumCorners[5].z),
    color);
  DrawLine(
    JPH::RVec3(frustumCorners[5].x, frustumCorners[5].y, frustumCorners[5].z),
    JPH::RVec3(frustumCorners[6].x, frustumCorners[6].y, frustumCorners[6].z),
    color
  );
  DrawLine(
    JPH::RVec3(frustumCorners[6].x, frustumCorners[6].y, frustumCorners[6].z),
    JPH::RVec3(frustumCorners[7].x, frustumCorners[7].y, frustumCorners[7].z),
    color
  );
  DrawLine(
    JPH::RVec3(frustumCorners[7].x, frustumCorners[7].y, frustumCorners[7].z),
    JPH::RVec3(frustumCorners[4].x, frustumCorners[4].y, frustumCorners[4].z),
    color
  );

  DrawLine(
    JPH::RVec3(frustumCorners[0].x, frustumCorners[0].y, frustumCorners[0].z),
    JPH::RVec3(frustumCorners[4].x, frustumCorners[4].y, frustumCorners[4].z),
    color
  );
  DrawLine(
    JPH::RVec3(frustumCorners[1].x, frustumCorners[1].y, frustumCorners[1].z),
    JPH::RVec3(frustumCorners[5].x, frustumCorners[5].y, frustumCorners[5].z),
    color
  );
  DrawLine(
    JPH::RVec3(frustumCorners[2].x, frustumCorners[2].y, frustumCorners[2].z),
    JPH::RVec3(frustumCorners[6].x, frustumCorners[6].y, frustumCorners[6].z),
    color
  );
  DrawLine(
    JPH::RVec3(frustumCorners[3].x, frustumCorners[3].y, frustumCorners[3].z),
    JPH::RVec3(frustumCorners[7].x, frustumCorners[7].y, frustumCorners[7].z),
    color
  );
}

void DebugRenderer::Render() {
    if (lines.empty() || !shader) return;

    GLuint shaderHandle = shader->GetHandle();
    glUseProgram(shaderHandle);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);

    glBufferData(GL_ARRAY_BUFFER, lines.size() * sizeof(DebugVertex), lines.data(), GL_STREAM_DRAW);

    glDrawArrays(GL_LINES, 0, (GLsizei)lines.size());

    glBindVertexArray(0);
    glUseProgram(0);
    glDisable(GL_BLEND);

    lines.clear();
}
}
